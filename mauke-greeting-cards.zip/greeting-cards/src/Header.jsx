const Header = () => {
  return (
    <header style={{ 
      textAlign: "center", 
      padding: "20px",
      backgroundColor: "red",
      color: "black", 
      fontSize: "2em",
      fontWeight: "bold",
    }}>
      <center> <h1>Welcome to Greeting Cards!</h1> </center>
    </header>
  );
};

export default Header;
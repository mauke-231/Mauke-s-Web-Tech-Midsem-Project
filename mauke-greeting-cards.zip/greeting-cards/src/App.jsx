import React from 'react';
import Header from './Header';
import GreetingCard from './GreetingCard';

const App = () => {
  const cards = [
    { title: "Happy Birthday!", message: "Wishing you a fantastic day filled with joy!" },
    { title: "Congratulations!", message: "Great job on your achievement!" },
    { title: "Thank You!", message: "Thanks for your kindness and support!" },
  ];

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      {/* include Header component */}
      <Header />

      {/* display GreetingCard components */}
      <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap" }}>
        {cards.map((card, index) => (
          <GreetingCard key={index} title={card.title} message={card.message} />
        ))}
      </div>
    </div>
  );
};

export default App;